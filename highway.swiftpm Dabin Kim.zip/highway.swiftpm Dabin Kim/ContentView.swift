import SwiftUI

struct ContentView: View
{
    var body: some View
    {
        NavigationView
        {
            ScrollView(.horizontal, showsIndicators: false)
            {
                ZStack
                {
                    //이미지를 맨 아래 깔아두기
                    //Image("wallWater")
                    Image("roadBg")
                        .resizable()
                        .ignoresSafeArea(.all)
                        .scaledToFill()
                    
                    HStack(spacing: 2200)
                    {
                        //네비게이션으로 다른 페이지로 가기
                        NavigationLink(destination: AnotherView1())
                        {
                            Image("maple02")
                                .resizable()
                                .frame(width: 150,height: 100)
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
//                                .background(Color.clear)
                                .cornerRadius(10)
                            
                        }
                        .offset(y: 150)
                        
                        //네비게이션으로 다른 페이지 가기2
                        NavigationLink(destination: AnotherView2())
                        {
                            Image("house")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .cornerRadius(10)
                            
                        }
                        .offset(x:-40)

                        
                        NavigationLink(destination: AnotherView3())
                        {
                            Image("bird")
                                .resizable()
                                .frame(width: 150,height: 90)
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .cornerRadius(10)
                        }
                        .offset(y: -90)
                        
                        NavigationLink(destination: AnotherView4())
                        {
                            Image("cutecat")
                                .resizable()

                                .frame(width: 150,height: 110)
                                .foregroundColor(.clear)
                                .padding()
                                .cornerRadius(10)
                        }.navigationBarHidden(true)
                            .offset(y:40)
                        
                        NavigationLink(destination: AnotherView5())
                        {
                            Image("nest")
                                .resizable()
                                .frame(width: 100,height: 100)
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .cornerRadius(10)
                                .offset(x: 20,y: -50)
                        }
                        
                    }
                }
                //            .navigationBarTitle("Scrollable Image")
            }
            .navigationBarHidden(true)
            .ignoresSafeArea(.all)
        }.navigationBarHidden(true)
    }
    
//    struct AnotherView1: View
//    {
//        var body: some View
//        {
//            VStack
//            {
//                Text("Another page")
//                    .font(.largeTitle)
//                    .padding()
//
//                NavigationLink(destination: ContentView())
//                {
//                    Text("Go back to the image")
//                        .font(.headline)
//                        .foregroundColor(.white)
//                        .padding()
//                        .background(Color.blue)
//                        .cornerRadius(10)
//                }
//            }
//        }
//    }
    
}
