import SwiftUI
import AVKit

struct AnotherView3: View {
    @State var number0: Int = 0
    @State var number1: Int = 0
    @State var number2: Int = 0
    @State var number3: Int = 0
    @State var number4: Int = 0
    @State var number5: Int = 0
    @State var animate0: Bool = false
    @State var animate1: Bool = false
    @State var animate2: Bool = false
    @State var animate3: Bool = false
    @State var animate4: Bool = false
    @State var animate5: Bool = false
    @Environment(\.presentationMode) var presentation
    
    private var timer = Timer.publish(every: 0.03, on: .main, in: .common).autoconnect()
    private let soundManager = SoundManager.instance
    private let emojiValue: [[String]] = [
        ["😲", "🤓", "😲", "🤩", "🌪️", "😗"],
        ["😗", "🧐", "🤓", "😲", "🤩", "🌪️"],
        ["🤓", "😲", "🤩", "🌪️", "😗", "🧐"],
        ["😲", "🤩", "🌪️", "😗", "🧐", "🤓"],
        ["🤩", "🌪️", "😗", "🧐", "🤓", "😲"],
        ["🌪️", "😗", "😲", "🤓", "🧐", "🤩"]
    ]
    private var titleSize = 45.0, emojiSize = 80.0, fontSize = 18.0, buttonTitleSize = 24.0
    private var padding_inset = 10.0, text_padding_inset = 30.0
    
    var body: some View {
        ZStack() {
            Image("board")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            VStack {
                Text("Design Thinking")
                    .font(.system(size: titleSize, weight: .bold))
                    .shadow(radius: 10)
                    .foregroundColor(.white)
                    .padding(.top, 20)
                HStack {
                    VStack{
                        //scrollView1
                        ScrollView() {
                            ScrollViewReader { proxy in
                                ForEach(0..<50) { index in
                                    Text("\(emojiValue[index%6][0])")
                                        .font(.system(size: emojiSize))
                                        .id(index)
                                }
                                .onReceive(timer) { _ in
                                    if animate0 {
                                        withAnimation {
                                            if number0 < 50 {
                                                number0 += 1
                                                proxy.scrollTo(number0)
                                            }
                                        }
                                    }else{
                                        number0 = 0
                                    }
                                }
                            }
                        }
                        .simultaneousGesture(DragGesture(minimumDistance: 0), including: .all)
                        .padding(.leading, padding_inset)
                        .padding(.trailing, padding_inset)
                            
                        Text("Claire")
                            .frame(alignment: .center)
                            .font(.system(size: fontSize))
                            .foregroundColor(.white)
                            .padding(.leading, text_padding_inset)
                            .padding(.trailing, text_padding_inset)
                        }
                    VStack{
                        //scrollView2
                        ScrollView() {
                            ScrollViewReader { proxy in
                                ForEach(0..<50) { index in
                                    Text("\(emojiValue[index%6][1])")
                                        .font(.system(size: emojiSize))
                                        .id(index)
                                }
                                .onReceive(timer) { _ in
                                    if animate1 {
                                        withAnimation {
                                            if number1 < 50 {
                                                number1 += 1
                                                proxy.scrollTo(number1)
                                            }
                                        }
                                    }else{
                                        number1 = 0
                                    }
                                }
                            }
                        }
                        .simultaneousGesture(DragGesture(minimumDistance: 0), including: .all)
                        .padding(.leading, padding_inset)
                        .padding(.trailing, padding_inset)
                            
                        Text("Helia")
                            .frame(alignment: .center)
                            .font(.system(size: fontSize))
                            .foregroundColor(.white)
                            .padding(.leading, text_padding_inset)
                            .padding(.trailing, text_padding_inset)
                    }
                    
                    VStack{
                        //scrollView3
                        ScrollView() {
                            ScrollViewReader { proxy in
                                ForEach(0..<50) { index in
                                    Text("\(emojiValue[index%6][2])")
                                        .font(.system(size: emojiSize))
                                        .id(index)
                                }
                                .onReceive(timer) { _ in
                                    if animate2 {
                                        withAnimation {
                                            if number2 < 50 {
                                                number2 += 1
                                                proxy.scrollTo(number2)
                                            }
                                        }
                                    }else{
                                        number2 = 0
                                    }
                                }
                            }
                        }
                        .simultaneousGesture(DragGesture(minimumDistance: 0), including: .all)
                        .padding(.leading, padding_inset)
                        .padding(.trailing, padding_inset)
                            
                        Text("Tyler")
                            .frame(alignment: .center)
                            .font(.system(size: fontSize))
                            .foregroundColor(.white)
                            .padding(.leading, text_padding_inset)
                            .padding(.trailing, text_padding_inset)
                        }
                        
                    VStack {
                        //scrollView4
                        ScrollView() {
                            ScrollViewReader { proxy in
                                ForEach(0..<50) { index in
                                    Text("\(emojiValue[index%6][3])")
                                        .font(.system(size: emojiSize))
                                        .id(index)
                                }
                                .onReceive(timer) { _ in
                                    if animate3 {
                                        withAnimation {
                                            if number3 < 50 {
                                                number3 += 1
                                                proxy.scrollTo(number3)
                                            }
                                        }
                                    }else{
                                        number3 = 0
                                    }
                                }
                            }
                        }
                        .simultaneousGesture(DragGesture(minimumDistance: 0), including: .all)
                        .padding(.leading, padding_inset)
                        .padding(.trailing, padding_inset)
                            
                        Text("Goggins")
                            .frame(alignment: .center)
                            .font(.system(size: fontSize))
                            .foregroundColor(.white)
                            .padding(.leading, text_padding_inset)
                            .padding(.trailing, text_padding_inset)
                    }
                        
                    VStack {
                        //scrollView5
                        ScrollView() {
                            ScrollViewReader { proxy in
                                ForEach(0..<50) { index in
                                    Text("\(emojiValue[index%6][4])")
                                        .font(.system(size: emojiSize))
                                        .id(index)
                                }
                                .onReceive(timer) { _ in
                                    if animate4 {
                                        withAnimation {
                                            if number4 < 50 {
                                                number4 += 1
                                                proxy.scrollTo(number4)
                                            }
                                        }
                                    }else{
                                        number4 = 0
                                    }
                                }
                            }
                        }
                        .simultaneousGesture(DragGesture(minimumDistance: 0), including: .all)
                        .padding(.leading, padding_inset)
                        .padding(.trailing, padding_inset)
                            
                        Text("Rash")
                            .frame(alignment: .center)
                            .font(.system(size: fontSize))
                            .foregroundColor(.white)
                            .padding(.leading, text_padding_inset)
                            .padding(.trailing, text_padding_inset)
                    }
                        
                    VStack {
                        //ScrollView6
                        ScrollView() {
                            ScrollViewReader { proxy in
                                ForEach(0..<50) { index in
                                    Text("\(emojiValue[index%6][5])")
                                        .font(.system(size: emojiSize))
                                        .id(index)
                                }
                                .onReceive(timer) { _ in
                                    if animate5 {
                                        withAnimation {
                                            if number5 < 50 {
                                                number5 += 1
                                                proxy.scrollTo(number5)
                                            }
                                        }
                                    }else{
                                        number5 = 0
                                    }
                                }
                            }
                        }
                        .simultaneousGesture(DragGesture(minimumDistance: 0), including: .all)
                        .padding(.leading, padding_inset)
                        .padding(.trailing, padding_inset)
                            
                        Text("Zett")
                            .frame(alignment: .center)
                            .font(.system(size: fontSize))
                            .foregroundColor(.white)
                            .padding(.leading, text_padding_inset)
                            .padding(.trailing, text_padding_inset)
                    }
                }
                .frame(height: 120)
                .padding(.bottom, 10)
                    
                HStack{
                    Button(action: {
                        self.presentation.wrappedValue.dismiss()
                    }, label: {
                        Image("button_image")
                            .resizable()
                            .frame(width: 80, height: 40)
                    })
                    .offset(x: -230)
                        
                    Button(action: autoScroll, label: {
                        Image("note")
                            .resizable()
                            .frame(width: 150, height: 60)
                    })
                    .foregroundColor(Color(.black))
                    .offset(x: -50)
                }
            }
        }
        .navigationBarBackButtonHidden()
    }
}

extension AnotherView3 {
    func autoScroll() {
        if animate0 {
            animate0 = false
            animate1 = false
            animate2 = false
            animate3 = false
            animate4 = false
            animate5 = false
        }else{
            animate0 = true
            soundManager.playSound()
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                animate1 = true
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                    animate2 = true
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                        animate3 = true
                        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                            animate4 = true
                            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1) {
                                animate5 = true
                            }
                        }
                    }
                }
            }
        }
    }
}

struct AnotherView3_Previews: PreviewProvider {
    static var previews: some View {
        AnotherView3().previewInterfaceOrientation(.landscapeRight)
    }
}
