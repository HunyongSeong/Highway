import SwiftUI

//extension Text {
////    @backDeployed(before: iOS 16.2)
//    @available(iOS 16.2, *)
//    public func monospaced(_ isActive: Bool) -> Text {
//        fatalError("Implementation here")
//    }
//}

struct AnotherView1: View {
    @AppStorage("onboarding") var isOnboardingViewActive: Bool = false

    @State var firstNaviLinkActive = false

    @State var animate : Bool = false
    @State private var isAnimating: Bool = true
    @State private var isAnimatingBack: Bool = false
    
    @Environment(\.presentationMode) var presentation // <--🔴


    //구조체에서 값변경이 안되는 특징때문에 @State 키워드를 사용.
    //그리고 그 값을 다른 뷰들에서 사용하기 위해서 @Binding 키워드를 사용.
    
    //이모지를 넣어주세요 마지막값을 목표값으로 넣어주세요

    
    @State var emoji1 = ["🍁", "😕", "😗", "😙", "💪", "😌", "😆", "😉", "😒"]
    @State var emoji2 = ["🍁", "🤭", "😲", "😆", "🥳", "🤩", "😆", "🥰", "😨"]
    @State var emoji3 = ["🍁", "🤔", "🤓", "😎", "😔", "😇", "😆", "😉", "😰"]
    @State var emoji4 = ["🍁", "😟", "😲", "😆", "🤩", "😅", "😅", "😉", "👻"]
    @State var emoji5 = ["🍁", "🥶", "🤩", "😄", "😁", "🥳", "😆", "😉", "😳"]
    @State var emoji6 = ["🍁", "🧐", "🌪️", "🍔", "🎂", "🍻", "😆", "😉", "🤩"]
    
    var body: some View {
        
        NavigationView { // Navigation have to locate to the Top
        ZStack{
                Image("maple01")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea(.all, edges: .all)
                    .offset(y: isAnimating ? 15 : -15)
                    .opacity(1)
                    .animation(
                        Animation
                            .easeInOut(duration: 1.5)
                            .repeatForever()
                        , value: isAnimating
                    )
                    .onAppear(perform: { //(2) Main Thread
                        // (1) this dispatch queue is responsible for executing any user or system activity
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: { isAnimating = false // it moves three seconds later

                        })
                    })
                
                VStack {
                    
//                    Spacer()
                    Spacer()
                    
                    // Rounded Text is available on iOS 16.1
                    // So we have to use below code ->
                    if #available(iOS 16.1, *) {
                        Text("Academy Story🍁")
                            .fontDesign(.rounded)
                            .fontWeight(.bold)
                            .font(.system(size: 45))
                            .foregroundColor(.white)
                            .bold()
                            .offset(x: 0, y: -10)

                    } else {
                        Text("Academy Story🍁")
                            .fontWeight(.bold)
                            .font(.system(size: 45))
                            .foregroundColor(.white)
                            .bold()
                        
                    }
                    //Rolling을 넣어준다
                    
                    
                    if #available(iOS 16.0, *) {
                        HStack {
                            VStack{
                                Rolling(font: .system(size: 80), emoji: $emoji1, animate: $animate)
                                Text("Claire")
                                    .frame(width:70)
                                    .padding(12)
                                    .background(RoundedRectangle(cornerRadius: 30)
                                    .fill(Color.white))
                            }
                            .padding(3)

                            VStack{
                                Rolling(font: .system(size: 80), emoji: $emoji2, animate: $animate)

                                Text("Helia")
                                    .frame(width:70)
                                    .padding(12)
                                    .background(RoundedRectangle(cornerRadius: 30)
                                    .fill(Color.white))
                                
                            }
                            .padding(3)
                            
                            VStack{
                                Rolling(font: .system(size: 80), emoji: $emoji3, animate: $animate)

                                Text("Tyler")
                                    .frame(width:70)
                                    .padding(12)
                                    .background(RoundedRectangle(cornerRadius: 30)
                                    .fill(Color.white))
                            }
                            .padding(3)

                            VStack{
                                Rolling(font: .system(size: 80), emoji: $emoji4, animate: $animate)

                                Text("Rash")
                                    .frame(width:70)
                                    .padding(12)
                                    .background(RoundedRectangle(cornerRadius: 30)
                                    .fill(Color.white))
                            }
                            .padding(3)

                            VStack{
                                Rolling(font: .system(size: 80), emoji: $emoji5, animate: $animate)

                                Text("Goggins")
                                    .frame(width:70)
                                    .padding(12)
                                    .background(RoundedRectangle(cornerRadius: 30)
                                    .fill(Color.white))
                            }
                            .padding(3)

                            VStack{
                                Rolling(font: .system(size: 80), emoji: $emoji6, animate: $animate)
                                //롤링만 옵셋 와이축
                                Text("Zett")
                                    .frame(width:70)
                                    .padding(12)
                                    .background(RoundedRectangle(cornerRadius: 30)
                                    .fill(Color.white))
                            }
                            .padding(3)

                            
                        }
                        
                        .offset(x:0, y: -40)
                        .font(.system(size:18))
                        .bold()
                    } else {
                        // Fallback on earlier versions
                        HStack {
                            Text("Claire")
                                .frame(width:70)
                                .padding(12)
                            Text("Helia")
                                .frame(width:70)
                                .padding(12)
                            Text("Tyler")
                                .frame(width:70)
                                .padding(12)
                            Text("Rash")
                                .frame(width:70)
                                .padding(12)
                            Text("Goggins")
                                .frame(width:70)
                                .padding(12)
                            Text("Zett")
                                .frame(width:70)
                                .padding(12)
                        }
                        .offset(x:0, y: -10)
                        .font(.system(size:18))
                    }
                   
                    
                    
                    HStack{
                        // Navigation
                        VStack {
                            
//                            Text("This is Main page.")
//                                .bold()
//                            NavigationLink(destination: SecondPage(firstNaviLinkActive: $firstNaviLinkActive), isActive: $firstNaviLinkActive) {
                            Button {
                                self.presentation.wrappedValue.dismiss()
                            } label: {
                                Text("뒤로가기")
                            }

//                                Text("뒤로가기")
                                
//                                    .buttonStyle(.borderedProminent)
                                    .font(.system(size: 24))
                                
                                    .foregroundColor(Color.white)
                                    .frame(width: 120, height: 60, alignment: .center)
                                    .background(RoundedRectangle(cornerRadius: 50)
                                    .fill(Color.orange))
                                    .offset(x:-250, y: -25) // <- ok // 17 차이
                                

                                /* ==============Erase==============
                                    .fontDesign(.rounded)
                                    .buttonStyle(.borderedProminent)
                                    .buttonBorderShape(.capsule)
                                    .font(.system(size: 24))
                                    .controlSize(.large)
                                    .offset(y: 17)
                                 */
                                
                            }
                            .navigationBarHidden(true)
                            if #available(iOS 16.1, *) {
                                Button("시작하기"){ // Act below code
                                    animate.toggle() // return true / false
                                    print("실행 출력")
//                                    playSound(sound: "chimeup", type: "mp3") //🟡🟡🟡
                                    isOnboardingViewActive = true

                                }
                                
                                .font(.system(size: 24))
                            
                                .foregroundColor(Color.white)
                                .frame(width: 120, height: 60, alignment: .center)
                                .background(RoundedRectangle(cornerRadius: 50)
                                .fill(Color.blue))
                                .offset(x: -60, y: -25) // <- ok // 17 차이
                                

                                
                            } else {
                                Button("시작하기"){ // Act below code
                                    animate.toggle() // return true / false
                                    print("실행 출력")
//                                    playSound(sound: "chimeup", type: "mp3") //🟡🟡🟡

                                }
                                .buttonStyle(.borderedProminent)
                                .buttonBorderShape(.capsule)
                                .font(.system(size: 24))
                                .controlSize(.large)
                            }
                        // Navigation End
                        
//================================기존 버튼 제거==============================//
//                        Button ("뒤로가기") {
//                            print("back")
//                        }
//                        //                    .bold()
//                        //                    .fontDesign(.rounded)
//                        .buttonStyle(.borderedProminent) // Basic button style
//                        .buttonBorderShape(.capsule) // capsule style
//                        .font(.system(size: 24))
//                        .controlSize(.large)
//
//                        Spacer()
//                        Spacer()
//                        Spacer()
//=========================================================================//
                        
                        // Rounded Text is available on iOS 16.1
                        // So we have to use below code ->
                        
                            
                        }
                    }
                    //Spacer()
                }

            }
        .navigationBarHidden(true)
    }
//        .onAppear(perform: { //(2) Main Thread
//            // (1) this dispatch queue is responsible for executing any user or system activity
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: { isAnimating = false // it moves three seconds later
//
//            })
//        })
    }



//landscapeView
struct AnotherView1_Previews: PreviewProvider {
    static var previews: some View {
//        ContentView().previewInterfaceOrientation(.landscapeRight) // 🔴🔴🔴
        AnotherView1()
    }
}
