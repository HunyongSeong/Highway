//
//  SoundManager.swift
//  scrollViewSlot
//
//  Created by hyebin on 2023/03/28.
//

import SwiftUI
import AVKit
 
class SoundManager {
    static let instance = SoundManager()
    var player: AVAudioPlayer?
       
    func playSound() {
        guard let url = Bundle.main.url(forResource:"slot", withExtension: ".m4a") else { return }
        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.play()
        } catch {
            print(error.localizedDescription)
        }
    }
}
