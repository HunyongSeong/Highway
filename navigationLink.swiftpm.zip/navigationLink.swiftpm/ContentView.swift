import SwiftUI

// ContentView 코드

import SwiftUI

struct ContentView: View {
    @State var firstNaviLinkActive = false
    var body: some View {
        
        NavigationView { // Navigation
            VStack {
                Text("This is Main page.")
                    .bold()
                NavigationLink(destination: SecondPage(firstNaviLinkActive: $firstNaviLinkActive), isActive: $firstNaviLinkActive) {
                    Text("Click Here")
                        .foregroundColor(Color.white)
                        .frame(width: 100, height: 60, alignment: .center)
                        .background(RoundedRectangle(cornerRadius: 10)
                            .fill(Color.red))
                }
                .navigationBarHidden(true)
            }
        } // Navigation End
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


