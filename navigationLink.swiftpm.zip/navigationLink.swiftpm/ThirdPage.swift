//
//  ThirdPage.swift
//  navigationLink
//
//  Created by David Goggins on 2023/03/30.
//
// ThirdView 코드 (마지막화면)

import SwiftUI

struct ThirdPage: View {
    @Binding var firstNaviLinkActive: Bool
    var body: some View {
        HStack{
            VStack{
                Spacer()
                
                Button(action: {
                    firstNaviLinkActive = false
                }, label: {
                    Text("Main으로 돌아가기")
                        
                        .foregroundColor(Color.white)
                        .frame(width: 100, height: 60, alignment: .center)
                        .background(RoundedRectangle(cornerRadius: 10)
                            .fill(Color.purple))
                })
            }
            Spacer()
        }
    }
}


struct ThirdPage_Previews: PreviewProvider {
    static var previews: some View {
        ThirdPage(firstNaviLinkActive: .constant(true))
    }
}
