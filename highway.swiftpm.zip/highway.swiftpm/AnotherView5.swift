//
//  AnotherView5.swift
//  slotDemo2
//
//  Created by qwd on 2023/03/28.


import SwiftUI

struct AnotherView5: View {
    @State var animate : Bool = false
    @State private var showingAlert = false

    
    //이모지를 넣어주세요 마지막값을 목표값으로 넣어주세요
    @State var emoji1 = ["😕", "😗", "😙", "💪", "😌", "😆", "😉","😕","💪"]
    @State var emoji2 = ["🤭", "😲", "😆", "🥳", "🤩", "😆", "😉","😕","🥳"]
    @State var emoji3 = ["🤔", "🤓", "😎", "😔", "😇", "😆", "😉","😕","😔"]
    @State var emoji4 = ["😟", "😲", "😆", "🤩", "😅", "😅", "😉","😕","🤩"]
    @State var emoji5 = ["🥶", "🤩", "😄", "😁", "🥳", "😆", "😉","😕","😁"]
    @State var emoji6 = ["🧐", "🌪️", "🍔", "🎂", "🍻", "😆", "😉","😕","🎂"]
    
    @State var tag:Int? = nil
    
    var body: some View {
        NavigationView {
            VStack {
                Spacer()
                //타이틀
                HStack{
                    Image(systemName: "star.fill")
                        .foregroundColor(.pink)
                        .font(.system(size: 25))
                    Text("MC1 Presentation")
                        .font(.system(size: 45))
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                    Image(systemName: "star.fill")
                        .foregroundColor(.pink)
                        .font(.system(size: 25))
                }
                ZStack{
                    HStack{
                        ForEach(1..<7, id:\.self){_ in
                            Rectangle()
                                .frame(width: 87, height: 87)
                                .opacity(0.27)
                                .cornerRadius(10)
                                .foregroundColor(self.animate ? Color(.systemPink) : Color(.systemGray4))
                                .animation(.easeIn(duration: 1).delay(1), value: animate)
                                .padding(-3)
                                .offset(x:5, y:0)
                        }
                }
                //이모지 롤링
                HStack{
                    Rolling(font: .system(size: 80), emoji: $emoji1, animate: $animate)
                    Rolling(font: .system(size: 80), emoji: $emoji2, animate: $animate)
                    Rolling(font: .system(size: 80), emoji: $emoji3, animate: $animate)
                    Rolling(font: .system(size: 80), emoji: $emoji4, animate: $animate)
                    Rolling(font: .system(size: 80), emoji: $emoji5, animate: $animate)
                    Rolling(font: .system(size: 80), emoji: $emoji6, animate: $animate)
                }

                }
                VStack{
                    Text("Claire           Helia           Tyler          Rash        Goggins        Zett")
                }.font(.system(size:18))
                    .offset(x:0, y:-15)
                Spacer()
                // 버튼들
                HStack{
                    
                    Spacer()
                    Button("What's On Your Mind"){
                        animate.toggle()
                    }
                
                    .font(.system(size: 24,weight: .bold))
                    .foregroundColor(.white)
                    .padding(.all,7)
                    .padding([.leading, .trailing], 20)
                    .background(Color.pink)
                    .cornerRadius(20)
                    .offset(x:0, y:-25)
                    Spacer()
                    
                    ZStack{
                        NavigationLink(destination: goToMc2(), tag: 1, selection: self.$tag ) {
                            EmptyView()
                        }
                        
                        Button( action : {
                            self.tag = 1
                        }) {
                            Text("🔜")
                        }
                        .font(.system(size: 28))
                        .offset(x:0, y:-25)
                        //                .padding(.all,5)
                        //                .padding([.leading, .trailing], 10)
                        //                .background(Color.white)
                        //                .cornerRadius(20)
                    }
                }
                
            }
        }
    }
}


    
    //landscapeView
    struct AnotherView5_Previews: PreviewProvider {
        static var previews: some View {
            AnotherView5().previewInterfaceOrientation(.landscapeRight)
        }
    }
    

