import SwiftUI

struct ContentView: View
{
    var body: some View
    {
        NavigationView
        {
            ScrollView(.horizontal, showsIndicators: false)
            {
                ZStack
                {
                    //이미지를 맨 아래 깔아두기
                    //Image("wallWater")
                    Image("roadBg")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                    
                    HStack(spacing: 1000)
                    {
                        //네비게이션으로 다른 페이지로 가기
                        NavigationLink(destination: AnotherView1())
                        {
                            Text("Button")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)
                        }
                        
                        //네비게이션으로 다른 페이지 가기2
                        NavigationLink(destination: AnotherView2())
                        {
                            Text("Button")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)
                            
                        }
                        
                        NavigationLink(destination: AnotherView3())
                        {
                            Text("Button")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)
                        }
                        
                        NavigationLink(destination: AnotherView4())
                        {
                            Text("Button")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)
                        }.navigationBarHidden(true)
                        
                        NavigationLink(destination: AnotherView5())
                        {
                            Text("Button")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)
                        }
                        
                    }
                }
                //            .navigationBarTitle("Scrollable Image")
            }
        }
    }
    
    
    
    struct AnotherView1: View
    {
        var body: some View
        {
            VStack
            {
                Text("Another page")
                    .font(.largeTitle)
                    .padding()
                
                NavigationLink(destination: ContentView())
                {
                    Text("Go back to the image")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
            }
        }
    }
    
}
