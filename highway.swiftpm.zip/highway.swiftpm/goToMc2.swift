//
//  goToMc2.swift
//  slotDemo2
//
//  Created by qwd on 2023/03/30.
//

import SwiftUI

struct goToMc2: View {
    
    var body: some View {
        ZStack{
            lottieView(name: "test", loopMode: .loop)
                .fixedSize()
            lottieView(name:"party",loopMode: .loop)
                .background(Color.white.opacity(0.7))
            Text("🖤 Now: HIGHWAY🖤")
                .font(.system(size:40))
                .fontWeight(.bold)
                .foregroundColor(.black)
                .padding()
                .offset(x:0,y:-120)
            TimelineView(.cyclic(timeOffsets: [0.2, 0.4, 0.6])) {
                timeline in
                Emojis(date: timeline.date)
                
            }
        }

    }
}

struct Emojis: View {
    @State private var phase = 0
    let scales: [CGFloat] = [2.0, 3.1, 2.5]
    let date: Date
    var body: some View {

        HStack {
            Text("❤️")
                .font(.largeTitle)
                .scaleEffect(scales[phase])
                .animation(.spring(response: 0.20,
                                   dampingFraction: 0.24,
                                   blendDuration: 0.2),
                           value: phase)
                .onChange(of: date) { _ in
                    advanceAnimationPhase()
                }
                .onAppear {
                    advanceAnimationPhase()
                }
//                .offset(x:-100, y:0)
                .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 60))
            Text("🫶")
                .font(.largeTitle)
                .scaleEffect(scales[phase])
                .animation(.spring(response: 0.20,
                                   dampingFraction: 0.24,
                                   blendDuration: 0.2),
                           value: phase)
                .onChange(of: date) { _ in
                    advanceAnimationPhase()
                }
                .onAppear {
                    advanceAnimationPhase()
                }
                .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 60))

            Text("❤️")
                .font(.largeTitle)
                .scaleEffect(scales[phase])
                .animation(.spring(response: 0.20,
                                   dampingFraction: 0.24,
                                   blendDuration: 0.2),
                           value: phase)
                .onChange(of: date) { _ in
                    advanceAnimationPhase()
                }
                .onAppear {
                    advanceAnimationPhase()
                }
//                .offset(x:-100, y:0)
                .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 60))

            Text("🫶")
                .font(.largeTitle)
                .scaleEffect(scales[phase])
                .animation(.spring(response: 0.20,
                                   dampingFraction: 0.24,
                                   blendDuration: 0.2),
                           value: phase)
                .onChange(of: date) { _ in
                    advanceAnimationPhase()
                }
                .onAppear {
                    advanceAnimationPhase()
                }
//                .offset(x:-100, y:0)
                .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 60))

            Text("❤️")
                .font(.largeTitle)
                .scaleEffect(scales[phase])
                .animation(.spring(response: 0.20,
                                   dampingFraction: 0.24,
                                   blendDuration: 0.2),
                           value: phase)
                .onChange(of: date) { _ in
                    advanceAnimationPhase()
                }
                .onAppear {
                    advanceAnimationPhase()
                }
//                .offset(x:-100, y:0)
                .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 60))
            Text("🍻")
                .font(.largeTitle)
                .scaleEffect(scales[phase])
                .animation(.spring(response: 0.20,
                                   dampingFraction: 0.24,
                                   blendDuration: 0.2),
                           value: phase)
                .onChange(of: date) { _ in
                    advanceAnimationPhase()
                }
                .onAppear {
                    advanceAnimationPhase()
                }

            
    

        }
        .offset(x:-10,y:+30)
        .padding()
//        VStack{
//            Text("      Claire             Helia             Tyler              Rash         Goggins          Zett")
//        }
        if #available(iOS 16.0, *) {
            VStack{
                Text("Claire             Helia           Tyler              Rash         Goggins             Zett")
            }
            .offset(x:-10,y:+40)
            .font(.system(size:20,weight: .bold))
        } else {
            // Fallback on earlier versions
        }
        Text("p.s.여러분의 감정은 어떠셨나요?")
            .font(.system(size:30))
            .fontWeight(.bold)
            .foregroundColor(.black)
            .offset(x:0, y:+90)
        
        
    }
    
    func advanceAnimationPhase() {
        phase = (phase + 1) % (scales.count + 1)
    }
    
}


struct CyclicTimelineSchedule: TimelineSchedule {
    let timeOffsets: [TimeInterval]
    
    func entries(from startDate: Date, mode: TimelineScheduleMode) -> Entries {
        Entries(last: startDate, offsets: timeOffsets)
    }
    
    struct Entries: Sequence, IteratorProtocol {
        var last: Date
        let offsets: [TimeInterval]
        
        var idx: Int = -1
        
        mutating func next() -> Date? {
            idx = (idx + 1) % offsets.count
            
            last = last.addingTimeInterval(offsets[idx])
            
            return last
        }
    }
}

extension TimelineSchedule where Self == CyclicTimelineSchedule {
    static func cyclic(timeOffsets: [TimeInterval]) -> CyclicTimelineSchedule {
            .init(timeOffsets: timeOffsets)
    }
}



struct goToMc2_Previews : PreviewProvider{
    static var previews: some View{
        goToMc2().previewInterfaceOrientation(.landscapeRight)
    }
}

