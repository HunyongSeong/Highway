import SwiftUI

struct AppLoginUI: View {
    var body: some View {
        @State var tag:Int? = nil

        var body : some View{
            
            ZStack{
                NavigationLink(destination: MainTabView(), tag: 1, selection: self.$tag ) {
                  EmptyView()
                }
              
              Button( action : {
                self.tag = 1
              }) {
                Text("Button")
            }
        }
        
//        return NavigationView {
//            ZStack{
//
//                Color.red.edgesIgnoringSafeArea(.all) // 전체화면 색상 변경
//
//                VStack{
//
//                    LoginAction
//                    Text("Hi")
//                        .font(.system(size: 40))
//                        .offset(x: 100, y: 100)
//                }
//
//            }
//            // Navigation option
//            .navigationBarHidden(true)
//            .navigationBarBackButtonHidden(true)
//        }
    }
}

private extension AppLoginUI {
    var LoginAction: some View {
        HStack {
            Spacer()
            NavigationLink(destination: MainTabView()
                .navigationBarHidden(false)
                .navigationBarBackButtonHidden(false)){ // 클로저
                Text("App Main Login View") // location is..right

               //==== 버튼은 네비게이션으로는 안되나 보다 ====//
                Button(action: {
                    withAnimation {
//                        playSound(sound: "success", type: "m4a") // sound
//                        isOnboardingViewActive = true
                    }
                }, label: {
                    Image(systemName: "arrow.triangle.2.circlepath.circle.fill")
                        .imageScale(.large)
                    Text("Restart")
                        .font(.system(.title3, design: .rounded))
                        .fontWeight(.bold)
                }) //: BUTTON
                .buttonStyle(.borderedProminent) // bordered = greyColor, and..
                .buttonBorderShape(.capsule) // makes capsule shape button
                .controlSize(.large) // size
                

            }
            Spacer()
        }.padding() // 이 뷰의 특정 모서리에 동일한 패딩양 추가
    }
}
