//
//  MainTabView.swift
//  navigationOn
//
//  Created by David Goggins on 2023/03/30.
//

import SwiftUI

struct MainTabView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}









struct MainTabView_Previews: PreviewProvider {
    static var previews: some View {
        MainTabView()
    }
}
